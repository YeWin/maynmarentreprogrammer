/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'tt', {
	fontSize: {
		label: 'Зурлык',
		voiceLabel: 'Шрифт зурлыклары',
		panelTitle: 'Шрифт зурлыклары'
	},
	label: 'Шрифт',
	panelTitle: 'Шрифт исеме',
	voiceLabel: 'Шрифт'
} );
